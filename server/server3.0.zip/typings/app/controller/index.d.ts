// This file is created by egg-ts-helper@1.29.1
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportHome = require('../../../app/controller/home');
import ExportBookCollect = require('../../../app/controller/book/collect');
import ExportBookGetbook = require('../../../app/controller/book/getbook');
import ExportBookShelf = require('../../../app/controller/book/shelf');
import ExportManagerGoods = require('../../../app/controller/manager/goods');
import ExportManagerUser = require('../../../app/controller/manager/user');
import ExportOrderDeleteorder = require('../../../app/controller/order/deleteorder');
import ExportOrderGetorders = require('../../../app/controller/order/getorders');
import ExportOrderSetorder = require('../../../app/controller/order/setorder');
import ExportSignLogin = require('../../../app/controller/sign/login');
import ExportSignManagerLogin = require('../../../app/controller/sign/managerLogin');
import ExportSignRegister = require('../../../app/controller/sign/register');
import ExportVegetablesGet = require('../../../app/controller/vegetables/get');

declare module 'egg' {
  interface IController {
    home: ExportHome;
    book: {
      collect: ExportBookCollect;
      getbook: ExportBookGetbook;
      shelf: ExportBookShelf;
    }
    manager: {
      goods: ExportManagerGoods;
      user: ExportManagerUser;
    }
    order: {
      deleteorder: ExportOrderDeleteorder;
      getorders: ExportOrderGetorders;
      setorder: ExportOrderSetorder;
    }
    sign: {
      login: ExportSignLogin;
      managerLogin: ExportSignManagerLogin;
      register: ExportSignRegister;
    }
    vegetables: {
      get: ExportVegetablesGet;
    }
  }
}
