"use strict"

const Service = require("egg").Service

class BookService extends Service {
  async getbook() {}
}

module.exports = BookService
