"use strict"

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = (app) => {
  const { router, controller } = app
  router.get("/", controller.home.index)
  /* 登录注册 */
  //登录
  router.post("/sign/login", controller.sign.login.index)
  router.post("/sign/manager", controller.sign.managerLogin.index)
  //注册
  router.post("/sign/register", controller.sign.register.index)
  /*书籍操作 */
  //全部书籍
  router.get("/book/getbook", controller.book.getbook.index)
  //搜索书籍
  router.post("/book/getbook/search", controller.book.getbook.search)
  //收藏书籍
  router.post("/book/collect", controller.book.collect.index)
  //判断是否已经收藏
  router.post("/book/collect/judge", controller.book.collect.judgecollect)
  //获取书架书籍
  router.post("/book/shelf", controller.book.shelf.index)
  //修改暑假书籍数量
  router.post("/book/shelf/amountchange", controller.book.shelf.amountChange)
  //获得已选书籍的价格和数量
  router.post("/book/shelf/getmessage", controller.book.shelf.getmessage)
  //得到所有用户信息
  router.get("/manager/user/getusers", controller.manager.user.index)
  //删除某个用户
  router.post("/manager/user/delete", controller.manager.user.delete)
  //添加用户
  router.post("/manager/user/setnew", controller.manager.user.setnew)
  //删除书籍
  router.post("/manage/goods/delete", controller.manager.goods.delete)
  //新增书籍
  router.post("/manage/goods/setnew", controller.manager.goods.setnew)
  //设置订单
  router.post("/order/setorder", controller.order.setorder.index)
  //获取指定用户订单
  router.post("/order/getorders", controller.order.getorders.index)
  //删除某个订单
  router.post("/order/deleteorder", controller.order.deleteorder.index)
  //获取所有订单
  router.get("/order/getallorders", controller.order.getorders.getallorders)
  //获取所有蔬菜
  router.get("/vegetables/get", controller.vegetables.get.index)
}
