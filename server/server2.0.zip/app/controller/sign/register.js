const Controller = require("egg").Controller;
class loginController extends Controller {
  async index() {
    let query = this.ctx.request.body;
    const username = query.username;
    let sql = " SELECT username FROM users WHERE username = '" + username + "'";
    const res = await this.app.mysql.query(sql);

    console.log(res.length);
    if (res.length != 0) {
      this.ctx.body = {
        message: "已存在该用户，注册失败",
      };
    } else {
      const result = await this.app.mysql.insert("users", query);
      const insertSuccess = result.affectedRows === 1;
      this.ctx.body = {
        isSuccess: insertSuccess,
        message: "注册成功",
      };
    }
  }
}
module.exports = loginController;
